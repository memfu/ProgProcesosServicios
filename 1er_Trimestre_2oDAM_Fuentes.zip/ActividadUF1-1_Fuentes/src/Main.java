public class Main {
    public static void main(String[] args) {
        // Crear una instancia de la clase Proceso lanzador
         ProcesoLanzadorDefault lanzador = new ProcesoLanzadorDefault();
         lanzador.lanzarTriangulo();

        //ProcesoLanzadorUser lanzadorUser = new ProcesoLanzadorUser();
        //lanzadorUser.lanzarTriangulo();
    }
}
